<?php
function civicrmVersion( ) {
  return array( 'version'  => '4.0.8',
                'cms'      => 'Drupal',
                'revision' => '37931' );
}

